package com.romco.bracketeer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BracketeerApplicationTests {

	@Test
	void contextLoads() {
	}

}
