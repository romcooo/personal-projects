package com.romco.bracketeer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BracketeerApplication {

	public static void main(String[] args) {
		SpringApplication.run(BracketeerApplication.class, args);
	}

}
